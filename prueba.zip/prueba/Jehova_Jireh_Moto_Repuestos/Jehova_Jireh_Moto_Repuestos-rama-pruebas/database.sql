-- ==============================================================================
-- BASE DE DATOS: JEHOVA JIREH MOTO REPUESTOS
-- COMPATIBLE 100% CON MICROSOFT SQL SERVER (T-SQL / SSMS)
-- ==============================================================================

USE master;
GO

-- 1. CREACIÓN DE LA BASE DE DATOS
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'jehova_jireh_db')
BEGIN
    CREATE DATABASE jehova_jireh_db;
END
GO

USE jehova_jireh_db;
GO

-- Limpieza previa de tablas (en orden de dependencias)
IF OBJECT_ID('movimientos_inventario', 'U') IS NOT NULL DROP TABLE movimientos_inventario;
IF OBJECT_ID('detalle_ventas', 'U') IS NOT NULL DROP TABLE detalle_ventas;
IF OBJECT_ID('ventas', 'U') IS NOT NULL DROP TABLE ventas;
IF OBJECT_ID('detalle_compras', 'U') IS NOT NULL DROP TABLE detalle_compras;
IF OBJECT_ID('compras', 'U') IS NOT NULL DROP TABLE compras;
IF OBJECT_ID('productos', 'U') IS NOT NULL DROP TABLE productos;
IF OBJECT_ID('proveedores', 'U') IS NOT NULL DROP TABLE proveedores;
IF OBJECT_ID('clientes', 'U') IS NOT NULL DROP TABLE clientes;
IF OBJECT_ID('usuarios', 'U') IS NOT NULL DROP TABLE usuarios;
IF OBJECT_ID('categorias', 'U') IS NOT NULL DROP TABLE categorias;
IF OBJECT_ID('roles', 'U') IS NOT NULL DROP TABLE roles;
GO

-- ==============================================================================
-- 2. TABLAS DE CATÁLOGOS BASE Y SEGURIDAD
-- ==============================================================================

-- Tabla: ROLES
CREATE TABLE roles (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    descripcion VARCHAR(255) NULL,
    created_at DATETIME DEFAULT GETDATE()
);
GO

-- Tabla: USUARIOS
CREATE TABLE usuarios (
    id INT IDENTITY(1,1) PRIMARY KEY,
    rol_id INT NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    nombre_completo VARCHAR(150) NOT NULL,
    email VARCHAR(100) UNIQUE NULL,
    telefono VARCHAR(25) NULL,
    activo BIT DEFAULT 1,
    ultimo_acceso DATETIME NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_usuarios_roles FOREIGN KEY (rol_id) REFERENCES roles(id)
);
GO

-- Tabla: CATEGORÍAS
CREATE TABLE categorias (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(MAX) NULL,
    created_at DATETIME DEFAULT GETDATE()
);
GO

-- Tabla: CLIENTES
CREATE TABLE clientes (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    identificacion VARCHAR(30) NULL,
    telefono VARCHAR(25) NULL,
    email VARCHAR(100) NULL,
    direccion VARCHAR(MAX) NULL,
    tipo_cliente VARCHAR(30) DEFAULT 'General' CHECK (tipo_cliente IN ('General', 'Taller', 'Frecuente', 'Mayorista')),
    created_at DATETIME DEFAULT GETDATE()
);
GO

-- Tabla: PROVEEDORES
CREATE TABLE proveedores (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre_empresa VARCHAR(150) NOT NULL,
    contacto_nombre VARCHAR(100) NULL,
    identificacion_fiscal VARCHAR(30) NULL,
    telefono VARCHAR(25) NOT NULL,
    email VARCHAR(100) NULL,
    direccion VARCHAR(MAX) NULL,
    activo BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);
GO

-- ==============================================================================
-- 3. CATÁLOGO DE PRODUCTOS / REPUESTOS
-- ==============================================================================

CREATE TABLE productos (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo_sku VARCHAR(50) NOT NULL UNIQUE,
    codigo_barras VARCHAR(50) NULL,
    categoria_id INT NOT NULL,
    nombre VARCHAR(200) NOT NULL,
    descripcion VARCHAR(MAX) NULL,
    marca VARCHAR(100) NULL,
    modelo_compatible VARCHAR(255) NULL,
    ubicacion_estante VARCHAR(50) NULL,
    costo DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    precio_venta DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    stock_actual INT NOT NULL DEFAULT 0,
    stock_minimo INT NOT NULL DEFAULT 5,
    activo BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_productos_categorias FOREIGN KEY (categoria_id) REFERENCES categorias(id),
    CONSTRAINT chk_stock_minimo CHECK (stock_minimo >= 0),
    CONSTRAINT chk_precios CHECK (precio_venta >= 0 AND costo >= 0)
);
GO

-- ==============================================================================
-- 4. GESTIÓN DE COMPRAS
-- ==============================================================================

CREATE TABLE compras (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo_compra VARCHAR(30) NOT NULL UNIQUE,
    numero_factura_proveedor VARCHAR(50) NULL,
    proveedor_id INT NOT NULL,
    usuario_id INT NOT NULL,
    fecha_compra DATE NOT NULL,
    total DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    forma_pago VARCHAR(30) DEFAULT 'Efectivo' CHECK (forma_pago IN ('Efectivo', 'Transferencia', 'Crédito', 'Cheque')),
    estado VARCHAR(30) DEFAULT 'Completada' CHECK (estado IN ('Completada', 'Pendiente', 'Anulada')),
    observaciones VARCHAR(MAX) NULL,
    created_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_compras_proveedores FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
    CONSTRAINT fk_compras_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
GO

CREATE TABLE detalle_compras (
    id INT IDENTITY(1,1) PRIMARY KEY,
    compra_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL,
    costo_unitario DECIMAL(12, 2) NOT NULL,
    subtotal DECIMAL(12, 2) NOT NULL,
    CONSTRAINT fk_detcompras_compras FOREIGN KEY (compra_id) REFERENCES compras(id) ON DELETE CASCADE,
    CONSTRAINT fk_detcompras_productos FOREIGN KEY (producto_id) REFERENCES productos(id),
    CONSTRAINT chk_detcompra_cantidad CHECK (cantidad > 0)
);
GO

-- ==============================================================================
-- 5. FACTURACIÓN Y VENTAS (PUNTO DE VENTA / POS)
-- ==============================================================================

CREATE TABLE ventas (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo_venta VARCHAR(30) NOT NULL UNIQUE,
    cliente_id INT NULL,
    usuario_id INT NOT NULL,
    fecha_venta DATE NOT NULL,
    subtotal DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    descuento DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    total DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    forma_pago VARCHAR(30) DEFAULT 'Efectivo' CHECK (forma_pago IN ('Efectivo', 'Tarjeta', 'Transferencia', 'Crédito', 'Mixto')),
    estado VARCHAR(30) DEFAULT 'Completada' CHECK (estado IN ('Completada', 'Anulada', 'Pendiente')),
    notas VARCHAR(MAX) NULL,
    created_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_ventas_clientes FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
    CONSTRAINT fk_ventas_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
GO

CREATE TABLE detalle_ventas (
    id INT IDENTITY(1,1) PRIMARY KEY,
    venta_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(12, 2) NOT NULL,
    costo_historico DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    subtotal DECIMAL(12, 2) NOT NULL,
    CONSTRAINT fk_detventas_ventas FOREIGN KEY (venta_id) REFERENCES ventas(id) ON DELETE CASCADE,
    CONSTRAINT fk_detventas_productos FOREIGN KEY (producto_id) REFERENCES productos(id),
    CONSTRAINT chk_detventa_cantidad CHECK (cantidad > 0)
);
GO

-- ==============================================================================
-- 6. CONTROL KARDEX / MOVIMIENTOS DE INVENTARIO
-- ==============================================================================

CREATE TABLE movimientos_inventario (
    id INT IDENTITY(1,1) PRIMARY KEY,
    fecha DATETIME DEFAULT GETDATE(),
    producto_id INT NOT NULL,
    tipo_movimiento VARCHAR(50) NOT NULL CHECK (tipo_movimiento IN (
        'ENTRADA_INICIAL',
        'ENTRADA_COMPRA',
        'SALIDA_VENTA',
        'AJUSTE_ENTRADA',
        'AJUSTE_SALIDA',
        'DEFECTUOSO_GARANTIA',
        'DEVOLUCION_CLIENTE'
    )),
    cantidad INT NOT NULL,
    stock_anterior INT NOT NULL DEFAULT 0,
    stock_posterior INT NOT NULL DEFAULT 0,
    referencia_origen VARCHAR(100) NULL,
    motivo VARCHAR(255) NOT NULL,
    usuario_id INT NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    CONSTRAINT fk_mov_productos FOREIGN KEY (producto_id) REFERENCES productos(id),
    CONSTRAINT fk_mov_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
GO

-- ==============================================================================
-- 7. ÍNDICES DE RENDIMIENTO
-- ==============================================================================

CREATE NONCLUSTERED INDEX idx_productos_sku ON productos(codigo_sku);
CREATE NONCLUSTERED INDEX idx_productos_nombre ON productos(nombre);
CREATE NONCLUSTERED INDEX idx_productos_categoria ON productos(categoria_id);
CREATE NONCLUSTERED INDEX idx_ventas_fecha ON ventas(fecha_venta);
CREATE NONCLUSTERED INDEX idx_compras_fecha ON compras(fecha_compra);
CREATE NONCLUSTERED INDEX idx_movimientos_producto ON movimientos_inventario(producto_id);
GO

-- ==============================================================================
-- 8. VISTAS SQL PARA REPORTES Y DASHBOARDS
-- ==============================================================================

CREATE OR ALTER VIEW vista_stock_bajo AS
SELECT 
    p.id,
    p.codigo_sku,
    p.nombre AS repuesto,
    c.nombre AS categoria,
    p.stock_actual,
    p.stock_minimo,
    (p.stock_minimo - p.stock_actual) AS unidades_por_comprar,
    p.costo,
    p.precio_venta
FROM productos p
INNER JOIN categorias c ON p.categoria_id = c.id
WHERE p.stock_actual <= p.stock_minimo AND p.activo = 1;
GO

CREATE OR ALTER VIEW vista_kardex_completo AS
SELECT 
    m.id AS movimiento_id,
    m.fecha,
    p.codigo_sku,
    p.nombre AS repuesto,
    c.nombre AS categoria,
    m.tipo_movimiento,
    m.cantidad,
    m.stock_anterior,
    m.stock_posterior,
    m.referencia_origen,
    m.motivo,
    u.nombre_completo AS realizado_por,
    r.nombre AS rol_usuario
FROM movimientos_inventario m
INNER JOIN productos p ON m.producto_id = p.id
INNER JOIN categorias c ON p.categoria_id = c.id
INNER JOIN usuarios u ON m.usuario_id = u.id
INNER JOIN roles r ON u.rol_id = r.id;
GO

CREATE OR ALTER VIEW vista_top_productos_vendidos AS
SELECT 
    p.id AS producto_id,
    p.codigo_sku,
    p.nombre AS repuesto,
    c.nombre AS categoria,
    SUM(dv.cantidad) AS total_unidades_vendidas,
    SUM(dv.subtotal) AS ingreso_total_generado,
    SUM(dv.subtotal - (dv.costo_historico * dv.cantidad)) AS ganancia_neta_generada
FROM detalle_ventas dv
INNER JOIN productos p ON dv.producto_id = p.id
INNER JOIN categorias c ON p.categoria_id = c.id
INNER JOIN ventas v ON dv.venta_id = v.id
WHERE v.estado = 'Completada'
GROUP BY p.id, p.codigo_sku, p.nombre, c.nombre;
GO

CREATE OR ALTER VIEW vista_balance_inventario AS
SELECT 
    COUNT(p.id) AS total_tipos_repuestos,
    SUM(p.stock_actual) AS total_unidades_fisicas,
    SUM(p.stock_actual * p.costo) AS valor_total_costo,
    SUM(p.stock_actual * p.precio_venta) AS valor_total_venta,
    SUM(p.stock_actual * (p.precio_venta - p.costo)) AS ganancia_proyectada
FROM productos p
WHERE p.activo = 1;
GO

-- ==============================================================================
-- 9. INSERCIÓN DE DATOS INICIALES (CON IDENTITY_INSERT HABILITADO)
-- ==============================================================================

-- 1. Roles
SET IDENTITY_INSERT roles ON;
INSERT INTO roles (id, nombre, descripcion) VALUES
(1, 'Administrador', 'Control total administrativo y reportes'),
(2, 'Vendedor', 'Atención al cliente y facturación en caja'),
(3, 'Encargado de Inventario', 'Ingreso de compras, bodega y Kardex'),
(4, 'Contador', 'Balances contables y reportes de rentabilidad');
SET IDENTITY_INSERT roles OFF;
GO

-- 2. Usuarios
SET IDENTITY_INSERT usuarios ON;
INSERT INTO usuarios (id, rol_id, username, password_hash, nombre_completo, email, telefono) VALUES
(1, 1, 'admin', '123', 'Gilda Pérez', 'admin@jehovajireh.com', '+505 8888-0001'),
(2, 2, 'vendedor', '123', 'Ana Gómez', 'ventas@jehovajireh.com', '+505 8888-0002'),
(3, 3, 'inventario', '123', 'Roberto Silva', 'bodega@jehovajireh.com', '+505 8888-0003'),
(4, 4, 'contador', '123', 'Lic. Fernando Rivas (Granada)', 'contabilidad@jehovajireh.com', '+505 8888-0004');
SET IDENTITY_INSERT usuarios OFF;
GO

-- 3. Categorías
SET IDENTITY_INSERT categorias ON;
INSERT INTO categorias (id, nombre, descripcion) VALUES
(1, 'Motor y Partes Internas', 'Cilindros completos, pistones, anillos de pistón, bielas, válvulas, árbol de levas, balancines, empaques de motor, cadenas de tiempo y bombas de lubricación.'),
(2, 'Sistema Eléctrico y Encendido', 'Cerebros CDI, bobinas de alta/motor, motores de arranque, carbones, bombillos, relays, fusibles, rectificadores, ignición, mandos de luces/start y sistema eléctrico.'),
(3, 'Transmisión y Embrague', 'Cajas de cambios, kit de sprockets (catalinas y piñones), discos/fricciones de clutch, canastas de clutch, cadenas de tracción y bandas de tracción (scooters).'),
(4, 'Sistema de Frenos', 'Bombas de freno (delanteras y traseras), mangueras de freno y varillas de freno.'),
(5, 'Suspensión y Dirección', 'Amortiguadores, cunas de poste, bushing de tijera y retenedores de barras.'),
(6, 'Carburación y Combustible', 'Carburadores, llaves de combustible y tapones de tanque.'),
(7, 'Cables y Controles', 'Cables de acelerador, cables de clutch, manecillas de clutch y pedales (de encendido y de cambios).'),
(8, 'Chasis y Accesorios', 'Asientos, guardafangos, capas cubre moto, pitos (bocinas) y espejos/viseras.'),
(9, 'Rodamientos y Misceláneos', 'Todas las balineras, sellos de válvulas, herramientas, aceites y otros.');
SET IDENTITY_INSERT categorias OFF;
GO

-- 4. Clientes
SET IDENTITY_INSERT clientes ON;
INSERT INTO clientes (id, nombre_completo, identificacion, telefono, email, tipo_cliente) VALUES
(1, 'Cliente General (Mostrador)', '000-000000-0000X', '2222-0000', 'mostrador@jehovajireh.com', 'General'),
(2, 'Taller Hermanos Mendoza', '401-150885-0002K', '+505 8444-1234', 'taller.mendoza@gmail.com', 'Taller'),
(3, 'Carlos Estrada', '001-200392-0044L', '+505 8999-5544', 'carlos.estrada@yahoo.com', 'Frecuente');
SET IDENTITY_INSERT clientes OFF;
GO

-- 5. Proveedores
SET IDENTITY_INSERT proveedores ON;
INSERT INTO proveedores (id, nombre_empresa, contacto_nombre, identificacion_fiscal, telefono, email, direccion) VALUES
(1, 'Distribuidora Repuestos del Pacífico', 'Mario López', 'J0310000123456', '+505 8899-1122', 'ventas@pacificomotos.com', 'Managua, Pista Juan Pablo II'),
(2, 'Importadora Global Moto Parts', 'Elena Morales', 'J0310000987654', '+505 7766-3344', 'contacto@globalmotoparts.com', 'Masaya, Km 28 Carretera a Granada');
SET IDENTITY_INSERT proveedores OFF;
GO

-- 6. Catálogo de Repuestos
SET IDENTITY_INSERT productos ON;
INSERT INTO productos (id, codigo_sku, categoria_id, nombre, costo, precio_venta, stock_actual, stock_minimo) VALUES
(1, 'MAN037', 5, 'AMORTIGUADOR AKT TT150-180 - GENESIS SX200 VINI', 1661.75, 2326.45, 3, 5),
(2, 'AMO026', 5, 'AMORTIGUADORES GN125H VINI', 833.0, 1166.2, 5, 5),
(3, 'AMO033', 4, 'AMORTIGUADORES PULSAR 135-DISCOVER VINI', 1462.0, 2046.8, 5, 5),
(4, 'Ani088', 1, 'ANILLOS DE PISTON AG200 A MEDIDA 0.25 VINI', 127.5, 178.5, 10, 5),
(5, 'Ani089', 1, 'ANILLOS DE PISTON AG200 A MEDIDA 0.50 VINI', 127.5, 178.5, 10, 5),
(6, 'Ani059', 1, 'ANILLOS DE PISTON AG200-UM200-RAYBAR200 (67MM*15MM) STD VINI', 136.0, 190.4, 10, 5),
(7, 'Ani086', 1, 'ANILLOS DE PISTON CG150 STD VINI', 85.0, 119.0, 20, 5),
(8, 'Ani060', 1, 'ANILLOS DE PISTON CG200-WY200 63.5 MM STD VINI', 93.5, 130.9, 20, 5),
(9, 'Ani061', 1, 'ANILLOS DE PISTON GXT200-DR200 66MM STD VINI', 136.0, 190.4, 10, 5),
(10, 'Ani018', 1, 'ANILLOS DE PISTON GY200 69MM-198CM STD VINI', 106.25, 148.75, 10, 5),
(11, 'Ani062', 1, 'ANILLOS DE PISTON PULSAR 135-XCD125-PLATINA125 STD VINI', 125.8, 176.12, 20, 5),
(12, 'Ani066', 1, 'ANILLOS DE PISTON PULSAR 180 UG3-UG4 STD VINI', 136.0, 190.4, 20, 5),
(13, 'Ani098', 1, 'ANILLOS DE PISTON PULSAR NS200 STD VINI', 136.0, 190.4, 20, 5),
(14, 'ARB050', 1, 'ARBOL DE LEVAS AKT CR5 180 VINI', 433.5, 606.9, 10, 5),
(15, 'ARB032', 1, 'ARBOL DE LEVAS CG-GY200 NO BALANZA COMPLETA VINI', 357.0, 499.8, 20, 5),
(16, 'ARB042', 1, 'ARBOL DE LEVAS PULSAR 135 VINI', 365.5, 511.7, 20, 5),
(17, 'ARB058', 1, 'ARBOL DE LEVAS SCOOTER 125-150 VINI', 272.0, 380.8, 10, 5),
(18, 'ARB051', 1, 'ARBOL DE LEVAS WY200-JH150 MOTOR CADENA BUSHING VINI', 331.5, 464.1, 10, 5),
(19, 'ASI015', 8, 'ASIENTO CG RACING MODIFIC AZUL VINI', 841.5, 1178.1, 4, 5),
(20, 'Asi023', 8, 'ASIENTO CG RACING MODIFIED VINI', 765.0, 1071.0, 5, 5),
(21, 'Asi021', 8, 'ASIENTO RAYBAR 200-NXR125 BROSS-UM DSR 2026 VINI', 697.0, 975.8, 2, 5),
(22, 'BLN060', 1, 'BALANCINES DE MOTOR AN125 VINI', 119.0, 166.6, 10, 5),
(23, 'BLN061', 1, 'BALANCINES DE MOTOR APACHE160-180 VINI', 289.0, 404.6, 5, 5),
(24, 'BLN041', 1, 'BALANCINES DE MOTOR COMPLETOS HJ125-CG150-CG200 VINI', 144.5, 202.3, 15, 5),
(25, 'BLN042', 1, 'BALANCINES DE MOTOR WY125-JH150-WY200 VINI', 161.5, 226.1, 15, 5),
(26, 'Bal127', 9, 'BALINERA 6004 2RS VINI', 38.25, 53.55, 50, 5),
(27, 'Bal147', 9, 'BALINERA 6005 2RS VINI', 49.3, 69.02, 50, 5),
(28, 'Bal148', 9, 'BALINERA 6006 2RS VINI', 62.9, 88.06, 50, 5),
(29, 'Bal108', 9, 'BALINERA 6202 2RS VINI', 32.3, 45.22, 60, 5),
(30, 'Bal1013', 9, 'BALINERA 6204 2RS VINI', 49.3, 69.02, 50, 5),
(31, 'Bal020', 9, 'BALINERA 6301 2RS VINI', 38.25, 53.55, 60, 5),
(32, 'Bal100', 9, 'BALINERA 6302 2RS VINI', 40.8, 57.12, 50, 5),
(33, 'Bal125', 9, 'BALINERA DE CIGUEÑAL 6205 2RS YBR-XTZ VINI', 86.7, 121.38, 10, 5),
(34, 'Bal083', 9, 'BALINERA DE CIGUEÑAL 63-28 28MM*68MM VINI', 136.0, 190.4, 20, 5),
(35, 'Bal084', 9, 'BALINERA DE CIGUEÑAL 63-28 P5 28MM*72MM VINI', 165.75, 232.05, 20, 5),
(36, 'Bal082', 9, 'BALINERA DE CIGUEÑAL PULSAR135-BOXER-DISC-PLATINA VINI', 136.0, 190.4, 20, 5),
(37, 'Bal149', 2, 'BALINERA DE MOTOR DE ARRANQUE CG HK1010 VINI', 17.85, 24.99, 30, 5),
(38, 'Bal079', 9, 'BALINERA DE PROPULSOR CG200 NK 152312 VINI', 34.0, 47.6, 30, 5),
(39, 'BAN005', 3, 'BANDA DE TRACCION SCOOTER GY6125 835x20x30 VINI', 225.25, 315.35, 20, 5),
(40, 'Bie066', 1, 'BIELA KIT AKT150TT-NKD125 NXR125 BROSS-XR125L VINI', 348.5, 487.9, 10, 5),
(41, 'Bie043', 1, 'BIELA KIT GXT200-DR200 VINI', 527.0, 737.8, 10, 5),
(42, 'Bie053', 1, 'BIELA KIT PULSAR135-PLATINA125-BM150 VINI', 365.5, 511.7, 10, 5),
(43, 'Bie063', 1, 'BIELA KIT XCD125-PLATINA 125-DISCOVER 125 ST VINI', 323.0, 452.2, 10, 5),
(44, 'Bie040', 1, 'BIELA KIT XL185-XL125-CG150-CG125 VINI', 323.0, 452.2, 10, 5),
(45, 'Bie048', 1, 'BIELA KIT YBR125-XTZ125 VINI', 331.5, 464.1, 10, 5),
(46, 'Bie068', 1, 'BIELA KIT YUMBO200-UM200-PULSAR180 VINI', 408.0, 571.2, 5, 5),
(47, 'BOB098', 2, 'BOBINA DE ALTA CG-AKT TT150-EVO150 1 LINEA VINI', 119.0, 166.6, 20, 5),
(48, 'BOB079', 2, 'BOBINA DE MOTOR AKT CR5 VINI', 578.0, 809.2, 10, 5),
(49, 'BOB058', 2, 'BOBINA DE MOTOR CG 8X3 MOTOR VARILLA VINI', 408.0, 571.2, 10, 5),
(50, 'BOB059', 2, 'BOBINA DE MOTOR DISCOVER 125 ST VINI', 510.0, 714.0, 5, 5),
(51, 'BOB073', 2, 'BOBINA DE MOTOR GN125H-GXT200 VINI', 578.0, 809.2, 5, 5),
(52, 'BOM039', 1, 'BOMBA DE FRENO DELANTERA HJ125-GN125 BLANCA VINI', 233.75, 327.25, 10, 5),
(53, 'BOM046', 1, 'BOMBA DE FRENO DELANTERA PULSAR 135-180-220 VINI', 314.5, 440.3, 10, 5),
(54, 'BOM066', 1, 'BOMBA DE FRENO DELANTERA XL-GY200 NEGRA VINI', 255.0, 357.0, 10, 5),
(55, 'BOM087', 1, 'BOMBA DE FRENO TRASERA COMPLETA PULSAR NS200-RS200-180-220 VINI', 254.15, 355.81, 10, 5),
(56, 'BOM067', 1, 'BOMBA DE FRENO TRASERA DAYUN150-CON DEPOSITO VINI', 272.0, 380.8, 10, 5),
(57, 'BOM088', 1, 'BOMBA DE LUBRICACION AX100 VINI', 552.5, 773.5, 5, 5),
(58, 'BOM044', 1, 'BOMBA DE LUBRICACION CG150 39D C-ORING VINI', 114.75, 160.65, 30, 5),
(59, 'BOM073', 1, 'BOMBA DE LUBRICACION YUMBO 200-YARA 200 37D VINI', 110.5, 154.7, 20, 5),
(60, 'BUJ122', 2, 'BOMBILLO DE PIDEVIAS 12V VINI', 5.06, 7.08, 100, 5),
(61, 'BUJ081', 2, 'BOMBILLO DE STOP 12V VINI', 7.23, 10.12, 100, 5),
(62, 'BUC036', 5, 'BUSHING DE TIJERA KIT + EJE AKT TT150-TT180 VINI', 187.0, 261.8, 10, 5),
(63, 'BUC059', 5, 'BUSHING DE TIJERA KIT + EJE GY200-JH125L-XL185S VINI', 144.5, 202.3, 10, 5),
(64, 'BUC066', 5, 'BUSHING DE TIJERA KIT + EJE RAYBAR 200 VINI', 187.0, 261.8, 10, 5),
(65, 'CAB193', 7, 'CABLE ACELERADOR CG-WY VINI', 44.2, 61.88, 30, 5),
(66, 'CAB211', 7, 'CABLE ACELERADOR GIXXER 150 VINI', 72.25, 101.15, 20, 5),
(67, 'CAB187', 7, 'CABLE ACELERADOR GXT200 VINI', 44.2, 61.88, 20, 5),
(68, 'CAB143', 7, 'CABLE ACELERADOR PULSAR 135 VINI', 46.75, 65.45, 30, 5),
(69, 'CAB144', 7, 'CABLE ACELERADOR PULSAR180-220 VINI', 46.75, 65.45, 30, 5),
(70, 'CAB212', 3, 'CABLE CLUTCH CGL125 VINI', 46.75, 65.45, 20, 5),
(71, 'CAB213', 3, 'CABLE CLUTCH GN125H VINI', 55.25, 77.35, 20, 5),
(72, 'CAB314', 3, 'CABLE CLUTCH HJ125-7 VINI', 46.75, 65.45, 30, 5),
(73, 'CAB131', 3, 'CABLE CLUTCH XTZ125 (2012-2018) C-POLVERA VINI', 68.0, 95.2, 10, 5),
(74, 'CAB190', 3, 'CABLE CLUTCH YBR125 VINI', 83.3, 116.62, 20, 5),
(75, 'CAB090', 2, 'CABLE DE BOBINA ALTA UNIVERSAL ROLLO', 246.5, 345.1, 100, 5),
(76, 'CAB156', 4, 'CABLE FRENO YBR125 VINI', 83.3, 116.62, 10, 5),
(77, 'CAD081', 3, 'CADENA DE LUBRICACION RAYBAR200-RKS150 CONTRAPESA VINI', 59.5, 83.3, 20, 5),
(78, 'CAD032', 1, 'CADENA DE TIEMPO AKT CR5 VINI', 119.0, 166.6, 20, 5),
(79, 'CAD094', 1, 'CADENA DE TIEMPO APACHE 150-160-180 (409H 94L) VINI', 161.5, 226.1, 20, 5),
(80, 'CAD095', 1, 'CADENA DE TIEMPO CRF230-XT250 SERROW (2X3H 104L) VINI', 114.75, 160.65, 10, 5),
(81, 'CAD062', 1, 'CADENA DE TIEMPO PULSAR NS200-AS200-RS200(94L) VINI', 161.5, 226.1, 20, 5),
(82, 'CAD074', 1, 'CADENA DE TIEMPO SCOOTER-150F-22 (90L) VINI', 127.5, 178.5, 20, 5),
(83, 'CAD071', 1, 'CADENA DE TIEMPO XTZ125-YBR125 2006 2X3L 90L ORUGA VINI', 127.5, 178.5, 20, 5),
(84, 'CAD096', 1, 'CADENA DE TIEMPO YUMBO200 (3X4H 100L) VINI', 144.5, 202.3, 20, 5),
(85, 'CAD061', 3, 'CADENA DE TRACCION 520X120L EXTRA REFORZADA DORADA VINI', 344.25, 481.95, 20, 5),
(86, 'CAJ001', 3, 'CAJA DE CAMBIOS AKT180TT-CR5 (6 CAMBIOS) VINI', 1249.5, 1749.3, 5, 5),
(87, 'CAJ023', 3, 'CAJA DE CAMBIOS CG125-CG150-AKT 150 VINI', 935.0, 1309.0, 5, 5),
(88, 'CAJ029', 3, 'CAJA DE CAMBIOS CG200-RAYBAR200-250-UM200-CONTRAPESA VINI', 1190.0, 1666.0, 5, 5),
(89, 'CAJ046', 3, 'CAJA DE CAMBIOS GXT200 VINI', 2125.0, 2975.0, 5, 5),
(90, 'CAJ047', 3, 'CAJA DE CAMBIOS PULSAR NS125-BOXER150X MODERNA VINI', 1377.0, 1927.8, 2, 5),
(91, 'ARA050', 3, 'CANASTA CLUTCH AKT CR5-TT 180 (SOLA) VINI', 442.0, 618.8, 10, 5),
(92, 'ARA051', 3, 'CANASTA CLUTCH CG125-CG150-RKS150 73T COMPLETA VINI', 637.5, 892.5, 5, 5),
(93, 'DIR326', 8, 'CAPA CUBRE MOTO PREMIUM UNIVERSAL VINI', 382.5, 535.5, 3, 5),
(94, 'JUB024', 2, 'CARBONES MOTOR ARRANQUE CBF150-XR150L VINI', 55.25, 77.35, 20, 5),
(95, 'JUB040', 2, 'CARBONES MOTOR ARRANQUE CG125-150-200 VINI', 55.25, 77.35, 20, 5),
(96, 'JUB028', 2, 'CARBONES MOTOR ARRANQUE GXT200-GN125 VINI', 68.0, 95.2, 20, 5),
(97, 'JUB041', 2, 'CARBONES MOTOR ARRANQUE PULSAR NS200 VINI', 55.25, 77.35, 20, 5),
(98, 'CAR050', 6, 'CARBURADOR CG150 PZ27 VINI', 459.0, 642.6, 10, 5),
(99, 'CAR047', 6, 'CARBURADOR CG200-XL200-DAKAR200 VINI', 484.5, 678.3, 10, 5),
(100, 'CAR069', 6, 'CARBURADOR GIXXER 150 VINI', 1955.0, 2737.0, 10, 5),
(101, 'CAR070', 6, 'CARBURADOR SCOOTER GY6150 VINI', 756.5, 1059.1, 5, 5),
(102, 'CAR046', 6, 'CARBURADOR XL125-185-CG125 VINI', 467.5, 654.5, 10, 5),
(103, 'CDI027', 9, 'CEPO PARA CEREBRO REDONDO 6L (2PCS) VINI', 16.15, 22.61, 50, 5),
(104, 'CDI049', 2, 'CEREBRO CDI AK CR5-AK180 TT-180CRX VINI', 165.75, 232.05, 3, 5),
(105, 'CDI051', 2, 'CEREBRO CDI DAYUN 150 CUADRADO CORRIENTE DIRECTA C-CABLE VINI', 165.75, 232.05, 30, 5),
(106, 'CDI053', 2, 'CEREBRO CDI GXT200-GN125H-DR200 8L D-C VINI', 433.5, 606.9, 5, 5),
(107, 'CDI032', 2, 'CEREBRO CDI NXR125 REDONDO CORRIENTE DIRECTA C-CABLE VINI', 161.5, 226.1, 20, 5),
(108, 'CDI034', 2, 'CEREBRO CDI PULSAR 135 VINI', 408.0, 571.2, 5, 5),
(109, 'CDI055', 2, 'CEREBRO CDI PULSAR150-180 UG4', 357.0, 499.8, 5, 5),
(110, 'CDI059', 2, 'CEREBRO CDI YBR 125 VINI', 280.5, 392.7, 5, 5),
(111, 'CIL086', 1, 'CILINDRO COMPLETO AKT TTR150-EVO 150NE BULON 13 62M VINI', 1054.0, 1475.6, 10, 5),
(112, 'CIL160', 1, 'CILINDRO COMPLETO APACHE 160 RTR 62M 15M 2V VINI', 1419.5, 1987.3, 3, 5),
(113, 'CIL094', 1, 'CILINDRO COMPLETO CG125-HJ125-7 56M-15M VINI', 977.5, 1368.5, 8, 5),
(114, 'CIL087', 1, 'CILINDRO COMPLETO CG150 GRIS BULON 15 62-15M VINI', 1079.5, 1511.3, 8, 5),
(115, 'CIL144', 1, 'CILINDRO COMPLETO CG200 63.5MM-15M VINI', 1122.0, 1570.8, 8, 5),
(116, 'CIL161', 1, 'CILINDRO COMPLETO CRF230-LONCIN250 SX3-TRUENO GRIS 65.5-15B VINI', 1487.5, 2082.5, 2, 5),
(117, 'CIL162', 1, 'CILINDRO COMPLETO GY6150 SCOOTER 57-15M VINI', 918.0, 1285.2, 5, 5),
(118, 'CIL166', 1, 'CILINDRO COMPLETO JH125-WY125 CADENA ALTA COMPRESION 56.5-B15 VINI', 1096.5, 1535.1, 5, 5),
(119, 'CIL163', 1, 'CILINDRO COMPLETO LUCKY110 HJ110 52-13 VINI', 892.5, 1249.5, 3, 5),
(120, 'CIL143', 1, 'CILINDRO COMPLETO PLATINA 125 14-54M-2V VINI', 1326.0, 1856.4, 5, 5),
(121, 'CIL146', 1, 'CILINDRO COMPLETO PULSAR 135 54MM-14B-4V VINI', 1185.75, 1660.05, 10, 5),
(122, 'CIL138', 1, 'CILINDRO COMPLETO RAYBAR 250 NEGRO 65.5MM-15M VINI', 1190.0, 1666.0, 5, 5),
(123, 'CIL164', 1, 'CILINDRO COMPLETO SCOOTER 125 52-15 VINI', 833.0, 1166.2, 5, 5),
(124, 'CIL129', 1, 'CILINDRO COMPLETO UM200-RAYBAR200 67MM GRIS 16B VINI', 1232.5, 1725.5, 3, 5),
(125, 'CIL165', 1, 'CILINDRO COMPLETO WY150-JH150 62MM-15 VINI', 1105.0, 1547.0, 5, 5),
(126, 'CUN038', 5, 'CUNAS DE POSTE CG-XL125-XL185-AKT125 CONICA VINI', 76.5, 107.1, 30, 5),
(127, 'CUN039', 5, 'CUNAS DE POSTE CG-XL125-XL185-AKT125 REDONDA VINI', 76.5, 107.1, 30, 5),
(128, 'CUN042', 5, 'CUNAS DE POSTE HJ110 LUCKY VINI', 97.75, 136.85, 20, 5),
(129, 'CUN056', 5, 'CUNAS DE POSTE NXR-BROS CONICA VINI', 106.25, 148.75, 20, 5),
(130, 'CUN054', 5, 'CUNAS DE POSTE NXR-BROS REDONDA VINI', 106.25, 148.75, 20, 5),
(131, 'DEL054', 3, 'DISCOS DE CLUTCH CG125-150-YBR125 5PCS VINI', 106.25, 148.75, 20, 5),
(132, 'EMM080', 1, 'EMPAQUES DE MOTOR KIT CG150 VINI', 106.25, 148.75, 30, 5),
(133, 'EMM062', 1, 'EMPAQUES DE MOTOR KIT GXT200 VINI', 182.75, 255.85, 20, 5),
(134, 'EMM102', 1, 'EMPAQUES DE MOTOR KIT GY200-YUMBO 69MM VINI', 174.25, 243.95, 30, 5),
(135, 'EMM092', 1, 'EMPAQUES DE MOTOR KIT PULSAR 135-DISCOVER 150 VINI', 97.75, 136.85, 30, 5),
(136, 'DES029', 1, 'EMPAQUES DESCARBONADO DAKAR 200 69MM VINI', 51.0, 71.4, 30, 5),
(137, 'DES045', 1, 'EMPAQUES DESCARBONADO PULSAR 135 VINI', 38.25, 53.55, 30, 5),
(138, 'ENG013', 2, 'ENGRANAJE DE ARRANQUE + BALINERA CG200 MULTIBALINES VINI', 476.0, 666.4, 15, 5),
(139, 'ENG047', 2, 'ENGRANAJE DE ARRANQUE + BALINERA GENESIS RKS150 VINI', 297.5, 416.5, 15, 5),
(140, 'FRI045', 3, 'FRICCIONES HJ125-GXT200 VINI', 131.75, 184.45, 20, 5),
(141, 'FRI038', 3, 'FRICCIONES PULSAR-BOXER-DISCOVER VINI', 131.75, 184.45, 20, 5),
(142, 'FUS003', 2, 'FUSIBLE 15 AH GAVETA (100 UND) VINI', 1.61, 2.25, 200, 5),
(143, 'FUS004', 2, 'FUSIBLE 20 AH GAVETA (100UND) VINI', 1.61, 2.25, 200, 5),
(144, 'FUS005', 2, 'FUSIBLE 25 AH GAVETA (100 UND) VINI', 1.61, 2.25, 200, 5),
(145, 'FUS006', 2, 'FUSIBLE 30 AH GAVETA (100UND) VINI', 1.61, 2.25, 200, 5),
(146, 'GUA134', 8, 'GUARDAFANGO WR250F-YZ250F UNIVERSAL AZUL VINI', 289.0, 404.6, 3, 5),
(147, 'GUA135', 8, 'GUARDAFANGO WR250F-YZ250F UNIVERSAL BLANCO VINI', 289.0, 404.6, 3, 5),
(148, 'GUA136', 8, 'GUARDAFANGO WR250F-YZ250F UNIVERSAL NEGRO VINI', 289.0, 404.6, 3, 5),
(149, 'CPI037', 9, 'GUIAS DE TIEMPO (CEPILLOS) CBF150-TITAN150-DAYUN 150GY VINI', 106.25, 148.75, 20, 5),
(150, 'CPI019', 9, 'GUIAS DE TIEMPO (CEPILLOS) PULSAR 135 VINI', 93.5, 130.9, 20, 5),
(151, 'VAL016', 1, 'GUIAS DE VALVULAS CG125-150-200 CORTA RACING MODIFIC VINI', 85.0, 119.0, 10, 5),
(152, 'VAL088', 1, 'GUIAS DE VALVULAS CG125-CG200-300 VINI', 55.25, 77.35, 20, 5),
(153, 'INI055', 2, 'IGNICION AKT NKD125-SERPENTO CORAL150-TAYPAN VINI', 106.25, 148.75, 10, 5),
(154, 'MDC098', 2, 'IGNICION HAYATE VINI', 136.0, 190.4, 5, 5),
(155, 'LAV044', 6, 'LLAVE DE COMBUSTIBLE AKT -XL GRUESA VINI', 63.75, 89.25, 20, 5),
(156, 'LAV047', 9, 'LLAVIN DE TAPADERAS LATERALES YBR125-DT175-XTZ125 VINI', 55.25, 77.35, 10, 5),
(157, 'MDO073', 2, 'MANDO DER START PULSAR 135 VINI', 272.0, 380.8, 10, 5),
(158, 'MDO074', 2, 'MANDO DER START PULSAR NS200 VINI', 497.25, 696.15, 10, 5),
(159, 'MDO036', 2, 'MANDO DER START WY125-RAYBAR VINI', 127.5, 178.5, 10, 5),
(160, 'MDO075', 2, 'MANDO IZQ LUCES GXT200 VINI', 136.0, 190.4, 10, 5),
(161, 'MDO076', 2, 'MANDO IZQ LUCES PULSAR 135 VINI', 263.5, 368.9, 10, 5),
(162, 'MDO077', 2, 'MANDO IZQ LUCES PULSAR NS200 VINI', 497.25, 696.15, 10, 5),
(163, 'MCI074', 3, 'MANECILLA DE CLUTCH HJ125-WY COMPLETA VINI', 93.5, 130.9, 50, 5),
(164, 'MGA024', 4, 'MANGUERA DE FRENO DELANTERA GXT200 VINI', 134.3, 188.02, 10, 5),
(165, 'MGA013', 4, 'MANGUERA DE FRENO TRASERA 60CM UNIVERSAL VINI', 119.0, 166.6, 10, 5),
(166, 'MOT047', 2, 'MOTOR DE ARRANQUE AG200-XT225 VINI', 1228.25, 1719.55, 2, 5),
(167, 'MOT050', 2, 'MOTOR DE ARRANQUE CGL125-HJ125 9 DIENTES VINI', 722.5, 1011.5, 5, 5),
(168, 'MOT025', 2, 'MOTOR DE ARRANQUE GXT200-GN125-EN125 VINI', 705.5, 987.7, 5, 5),
(169, 'PAL035', 7, 'PEDAL DE CAMBIOS HJ125-7 VINI', 204.0, 285.6, 5, 5),
(170, 'PAT027', 7, 'PEDAL DE ENCENDIDO AKT TT150-TT180-TT200-GENESIS SX200-SX250 VINI', 187.0, 261.8, 10, 5),
(171, 'PAT028', 7, 'PEDAL DE ENCENDIDO GXT200 VINI', 136.0, 190.4, 10, 5),
(172, 'PAT029', 7, 'PEDAL DE ENCENDIDO HJ125 VINI', 173.4, 242.76, 10, 5),
(173, 'PIS197', 1, 'PISTON COMPLETO AG200-UM200-RAYBAR200 STD 67MM-B16 VINI', 404.6, 566.44, 10, 5),
(174, 'PIS166', 1, 'PISTON COMPLETO AKT CR5-CUPULA 200 STD B15 63 VINI', 303.45, 424.83, 10, 5),
(175, 'PIS193', 1, 'PISTON COMPLETO AKT EVO 150NE-TT150 (B13) 62MM VINI', 280.5, 392.7, 10, 5),
(176, 'PIS198', 1, 'PISTON COMPLETO APACHE 160 STD 62M-15-2V VINI', 314.5, 440.3, 5, 5),
(177, 'PIS199', 1, 'PISTON COMPLETO APACHE 180 RTR STD 2V-B15-62.5 VINI', 382.5, 535.5, 5, 5),
(178, 'PIS145', 1, 'PISTON COMPLETO CG125-WY125 (56MM*B15MM) STD VINI', 216.75, 303.45, 10, 5),
(179, 'PIS146', 1, 'PISTON COMPLETO CG150-WY150 (62MM*B15MM) STD VINI', 255.0, 357.0, 5, 5),
(180, 'PIS147', 1, 'PISTON COMPLETO CG200-WY200-XL200 (63.5MM*B15MM) STD VINI', 272.0, 380.8, 10, 5),
(181, 'PIS153', 1, 'PISTON COMPLETO DAYUN150-CBF150-RTX STD B14-57MM VINI', 272.0, 380.8, 10, 5),
(182, 'PIS152', 1, 'PISTON COMPLETO MODIFICADO CG200 63.5MM-B15 CON CUPULA RACING VINI', 420.75, 589.05, 5, 5),
(183, 'PIS148', 1, 'PISTON COMPLETO PULSAR 135 STD 54MM-B14 VINI', 297.5, 416.5, 10, 5),
(184, 'PIS162', 1, 'PISTON COMPLETO PULSAR 180 STD 63.5MM-B16 VINI', 331.5, 464.1, 5, 5),
(185, 'PIS163', 1, 'PISTON COMPLETO PULSAR NS200-RS200-AS200 72MM-B17 STD VINI', 408.0, 571.2, 5, 5),
(186, 'PIS149', 1, 'PISTON COMPLETO TORITO175-205 KIT LF200 B17-61MM VINI', 331.5, 464.1, 15, 5),
(187, 'PIT009', 8, 'PITO UNIVERSAL DL128ZB VINI', 63.75, 89.25, 50, 5),
(188, 'REC053', 2, 'RECTIFICADOR 4L RAYBAR200 CON DIODO VINI', 158.95, 222.53, 20, 5),
(189, 'REC055', 2, 'RECTIFICADOR AKT 180-CR5- GENESIS LONCIN SX250 SX3 VINI', 212.5, 297.5, 5, 5),
(190, 'REC056', 2, 'RECTIFICADOR BOXER BM150 VINI', 212.5, 297.5, 5, 5),
(191, 'REC057', 2, 'RECTIFICADOR PULSAR 135 VINI', 346.8, 485.52, 5, 5),
(192, 'RGL004', 3, 'REGULADORES DE CADENA TRACCION BROSS150-XR150-AKT TT150-180 VINI', 115.6, 161.84, 10, 5),
(193, 'RGL005', 3, 'REGULADORES DE CADENA TRACCION CG125-XL VINI', 21.25, 29.75, 20, 5),
(194, 'RGL006', 3, 'REGULADORES DE CADENA TRACCION WY125-CGL125-AKT HUNTER 150 VINI', 68.0, 95.2, 20, 5),
(195, 'CCH009', 2, 'RELAY DE ARRANQUE CG-WY VINI', 119.0, 166.6, 30, 5),
(196, 'CCH017', 2, 'RELAY DE ARRANQUE PULSAR 135-DISCOVER-RS200 VINI', 216.75, 303.45, 10, 5),
(197, 'RET122', 1, 'RETENEDORES DE BARRAS CG-AKT NKD 27-37-10.5 VINI', 28.9, 40.46, 30, 5),
(198, 'RET060', 1, 'RETENEDORES DE BARRAS PULSAR NS200-PULSAR180-220 VINI', 63.75, 89.25, 30, 5),
(199, 'RET092', 1, 'RETENEDORES DE BARRAS PULSAR135-DISC150-YBR125-2020-25 CRUX110-REV 30-42-10.5 VINI', 38.25, 53.55, 30, 5),
(200, 'RET115', 1, 'RETENEDORES DE BARRAS SZ150-NAGA 200-JIALING150 33X46X10.5 VINI', 46.75, 65.45, 30, 5),
(201, 'RET090', 1, 'RETENEDORES DE BARRAS XL-WY BOXER150 NS160-N160-NS125UG 31X43X10.5 VINI', 42.5, 59.5, 50, 5),
(202, 'RET065', 1, 'RETENEDORES DE BARRAS YBR125-CRUX110(VIEJA)-RX100-HJ125-7 (30*40.5*10.5) VINI', 42.5, 59.5, 30, 5),
(203, 'OTR362', 1, 'SELLOS DE VALVULAS EN125-GN125 VINI', 25.5, 35.7, 50, 5),
(204, 'OTR363', 1, 'SELLOS DE VALVULAS TORITO LF200 RE205 VINI', 25.5, 35.7, 30, 5),
(205, 'SIN025', 9, 'SINFIN DE VELOCIMETRO AKT TT150 VINI', 110.5, 154.7, 20, 5),
(206, 'SIS016', 9, 'SISTEMA ELECTRICO CG-DY125-ZS150 VINI', 408.0, 571.2, 5, 5),
(207, 'SIS023', 9, 'SISTEMA ELECTRICO SX150 - AKT150TT-ZX150L VINI', 535.5, 749.7, 5, 5),
(208, 'SPR175', 3, 'SPROCKET KIT AKT 150NE EVO 428H 41TX15T + 120L COMPLETO VINI', 391.0, 547.4, 10, 5),
(209, 'SPR209', 3, 'SPROCKET KIT AKT SL-NKD-EVO-SERPENTO CORAL-COBRA 428H 38X15T + 130L COMPLETO VINI', 416.5, 583.1, 10, 5),
(210, 'SPR309', 3, 'SPROCKET KIT AKT SL-NKD-EVO-SERPENTO CORAL-COBRA 428H 42X15T + 130L COMPLETO VINI', 442.0, 618.8, 10, 5),
(211, 'SPR310', 3, 'SPROCKET KIT FZ16 428H 40T X 14T + 132L COMPLETO VINI', 442.0, 618.8, 5, 5),
(212, 'SPR255', 3, 'SPROCKET KIT PULSAR 135 428H 43X15T + 130L DORADA COMPLETO VINI', 493.0, 690.2, 10, 5),
(213, 'SPR268', 3, 'SPROCKET KIT PULSAR NS200 428H 45X15T + 136 DORADA RACING COMPLETO VINI', 544.0, 761.6, 10, 5),
(214, 'SPR311', 3, 'SPROCKET KIT XR150L 428H 49T X 17T + 136L COMPLETO VINI', 493.0, 690.2, 5, 5),
(215, 'SPR126', 3, 'SPROCKET TRASERO CGL125 428H 38T CONCAVO VINI', 123.25, 172.55, 10, 5),
(216, 'BUJ257', 9, 'STOP TRASERO GN125H', 306.0, 428.4, 3, 5),
(217, 'TPO075', 6, 'TAPON DE TANQUE PULSAR 135 VINI', 399.5, 559.3, 10, 5),
(218, 'TEN021', 9, 'TENSOR AUTOMATICO BOXER BM150-BM100-PULSAR 135 GRIS VINI', 122.83, 171.96, 10, 5),
(219, 'VAL089', 1, 'VALVULAS DE MOTOR CG125-HJ125-7 (5MM) VINI', 178.5, 249.9, 30, 5),
(220, 'VAL090', 1, 'VALVULAS DE MOTOR CG150-AKT TT150-EVO150 VINI', 195.5, 273.7, 30, 5),
(221, 'VAL091', 1, 'VALVULAS DE MOTOR CG200 (5MM) VINI', 229.5, 321.3, 30, 5),
(222, 'VAL145', 1, 'VALVULAS DE MOTOR CG250-RAYBAR250 HI RPM ALTO CARBONO VINI', 263.5, 368.9, 10, 5),
(223, 'VAL092', 1, 'VALVULAS DE MOTOR CG250-YUMBO250-RAYBAR250 VINI', 238.0, 333.2, 10, 5),
(224, 'VAL134', 1, 'VALVULAS DE MOTOR DISCOVER 125 ST 4PCS VINI', 297.5, 416.5, 10, 5),
(225, 'VAL150', 1, 'VALVULAS DE MOTOR HONDA NAVI-CB1 VINI', 204.0, 285.6, 10, 5),
(226, 'VAL097', 1, 'VALVULAS DE MOTOR PULSAR 135 4PZS VINI', 306.0, 428.4, 20, 5),
(227, 'VAL148', 1, 'VALVULAS DE MOTOR PULSAR 180 VINI', 280.5, 392.7, 10, 5),
(228, 'VAL147', 1, 'VALVULAS DE MOTOR SCOOTER 150 VINI', 212.5, 297.5, 10, 5),
(229, 'VAL178', 1, 'VALVULAS DE MOTOR SCOOTER GY6 125 VINI', 136.0, 190.4, 10, 5),
(230, 'VAL149', 1, 'VALVULAS DE MOTOR SUZUKI AN125 VINI', 255.0, 357.0, 10, 5),
(231, 'VAL079', 1, 'VALVULAS DE MOTOR SUZUKI AX4 VINI', 229.5, 321.3, 10, 5),
(232, 'VAR022', 4, 'VARILLA DE FRENO CG125-TAYPAN-NKD125 VINI', 34.0, 47.6, 20, 5),
(233, 'VAR023', 4, 'VARILLA DE FRENO YBR125ED-G VINI', 46.75, 65.45, 10, 5),
(234, 'VAR016', 4, 'VARILLAS DE EMPUJE ALUMINIO CG150-AKT TT150-EVO-XM20 VINI', 68.0, 95.2, 30, 5),
(235, 'VAR017', 4, 'VARILLAS DE EMPUJE ALUMINIO CG-GY200-XM 200 VINI', 68.0, 95.2, 20, 5);
SET IDENTITY_INSERT productos OFF;
GO

-- =========================================
-- 7. Compras (VACIO)
-- =========================================

-- =========================================
-- 8. Ventas (VACIO)
-- =========================================

-- 9. Movimientos Kardex
SET IDENTITY_INSERT movimientos_inventario ON;
INSERT INTO movimientos_inventario (id, fecha, producto_id, tipo_movimiento, cantidad, stock_anterior, stock_posterior, referencia_origen, motivo, usuario_id) VALUES
(1, '2026-08-17T08:00:00', 1, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(2, '2026-08-17T08:00:00', 2, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(3, '2026-08-17T08:00:00', 3, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(4, '2026-08-17T08:00:00', 4, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(5, '2026-08-17T08:00:00', 5, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(6, '2026-08-17T08:00:00', 6, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(7, '2026-08-17T08:00:00', 7, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(8, '2026-08-17T08:00:00', 8, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(9, '2026-08-17T08:00:00', 9, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(10, '2026-08-17T08:00:00', 10, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(11, '2026-08-17T08:00:00', 11, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(12, '2026-08-17T08:00:00', 12, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(13, '2026-08-17T08:00:00', 13, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(14, '2026-08-17T08:00:00', 14, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(15, '2026-08-17T08:00:00', 15, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(16, '2026-08-17T08:00:00', 16, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(17, '2026-08-17T08:00:00', 17, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(18, '2026-08-17T08:00:00', 18, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(19, '2026-08-17T08:00:00', 19, 'ENTRADA_INICIAL', 4, 0, 4, 'INICIO', 'Carga inicial de inventario', 1),
(20, '2026-08-17T08:00:00', 20, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(21, '2026-08-17T08:00:00', 21, 'ENTRADA_INICIAL', 2, 0, 2, 'INICIO', 'Carga inicial de inventario', 1),
(22, '2026-08-17T08:00:00', 22, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(23, '2026-08-17T08:00:00', 23, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(24, '2026-08-17T08:00:00', 24, 'ENTRADA_INICIAL', 15, 0, 15, 'INICIO', 'Carga inicial de inventario', 1),
(25, '2026-08-17T08:00:00', 25, 'ENTRADA_INICIAL', 15, 0, 15, 'INICIO', 'Carga inicial de inventario', 1),
(26, '2026-08-17T08:00:00', 26, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(27, '2026-08-17T08:00:00', 27, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(28, '2026-08-17T08:00:00', 28, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(29, '2026-08-17T08:00:00', 29, 'ENTRADA_INICIAL', 60, 0, 60, 'INICIO', 'Carga inicial de inventario', 1),
(30, '2026-08-17T08:00:00', 30, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(31, '2026-08-17T08:00:00', 31, 'ENTRADA_INICIAL', 60, 0, 60, 'INICIO', 'Carga inicial de inventario', 1),
(32, '2026-08-17T08:00:00', 32, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(33, '2026-08-17T08:00:00', 33, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(34, '2026-08-17T08:00:00', 34, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(35, '2026-08-17T08:00:00', 35, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(36, '2026-08-17T08:00:00', 36, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(37, '2026-08-17T08:00:00', 37, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(38, '2026-08-17T08:00:00', 38, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(39, '2026-08-17T08:00:00', 39, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(40, '2026-08-17T08:00:00', 40, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(41, '2026-08-17T08:00:00', 41, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(42, '2026-08-17T08:00:00', 42, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(43, '2026-08-17T08:00:00', 43, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(44, '2026-08-17T08:00:00', 44, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(45, '2026-08-17T08:00:00', 45, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(46, '2026-08-17T08:00:00', 46, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(47, '2026-08-17T08:00:00', 47, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(48, '2026-08-17T08:00:00', 48, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(49, '2026-08-17T08:00:00', 49, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(50, '2026-08-17T08:00:00', 50, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(51, '2026-08-17T08:00:00', 51, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(52, '2026-08-17T08:00:00', 52, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(53, '2026-08-17T08:00:00', 53, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(54, '2026-08-17T08:00:00', 54, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(55, '2026-08-17T08:00:00', 55, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(56, '2026-08-17T08:00:00', 56, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(57, '2026-08-17T08:00:00', 57, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(58, '2026-08-17T08:00:00', 58, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(59, '2026-08-17T08:00:00', 59, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(60, '2026-08-17T08:00:00', 60, 'ENTRADA_INICIAL', 100, 0, 100, 'INICIO', 'Carga inicial de inventario', 1),
(61, '2026-08-17T08:00:00', 61, 'ENTRADA_INICIAL', 100, 0, 100, 'INICIO', 'Carga inicial de inventario', 1),
(62, '2026-08-17T08:00:00', 62, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(63, '2026-08-17T08:00:00', 63, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(64, '2026-08-17T08:00:00', 64, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(65, '2026-08-17T08:00:00', 65, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(66, '2026-08-17T08:00:00', 66, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(67, '2026-08-17T08:00:00', 67, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(68, '2026-08-17T08:00:00', 68, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(69, '2026-08-17T08:00:00', 69, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(70, '2026-08-17T08:00:00', 70, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(71, '2026-08-17T08:00:00', 71, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(72, '2026-08-17T08:00:00', 72, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(73, '2026-08-17T08:00:00', 73, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(74, '2026-08-17T08:00:00', 74, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(75, '2026-08-17T08:00:00', 75, 'ENTRADA_INICIAL', 100, 0, 100, 'INICIO', 'Carga inicial de inventario', 1),
(76, '2026-08-17T08:00:00', 76, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(77, '2026-08-17T08:00:00', 77, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(78, '2026-08-17T08:00:00', 78, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(79, '2026-08-17T08:00:00', 79, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(80, '2026-08-17T08:00:00', 80, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(81, '2026-08-17T08:00:00', 81, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(82, '2026-08-17T08:00:00', 82, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(83, '2026-08-17T08:00:00', 83, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(84, '2026-08-17T08:00:00', 84, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(85, '2026-08-17T08:00:00', 85, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(86, '2026-08-17T08:00:00', 86, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(87, '2026-08-17T08:00:00', 87, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(88, '2026-08-17T08:00:00', 88, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(89, '2026-08-17T08:00:00', 89, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(90, '2026-08-17T08:00:00', 90, 'ENTRADA_INICIAL', 2, 0, 2, 'INICIO', 'Carga inicial de inventario', 1),
(91, '2026-08-17T08:00:00', 91, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(92, '2026-08-17T08:00:00', 92, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(93, '2026-08-17T08:00:00', 93, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(94, '2026-08-17T08:00:00', 94, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(95, '2026-08-17T08:00:00', 95, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(96, '2026-08-17T08:00:00', 96, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(97, '2026-08-17T08:00:00', 97, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(98, '2026-08-17T08:00:00', 98, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(99, '2026-08-17T08:00:00', 99, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(100, '2026-08-17T08:00:00', 100, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(101, '2026-08-17T08:00:00', 101, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(102, '2026-08-17T08:00:00', 102, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(103, '2026-08-17T08:00:00', 103, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(104, '2026-08-17T08:00:00', 104, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(105, '2026-08-17T08:00:00', 105, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(106, '2026-08-17T08:00:00', 106, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(107, '2026-08-17T08:00:00', 107, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(108, '2026-08-17T08:00:00', 108, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(109, '2026-08-17T08:00:00', 109, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(110, '2026-08-17T08:00:00', 110, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(111, '2026-08-17T08:00:00', 111, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(112, '2026-08-17T08:00:00', 112, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(113, '2026-08-17T08:00:00', 113, 'ENTRADA_INICIAL', 8, 0, 8, 'INICIO', 'Carga inicial de inventario', 1),
(114, '2026-08-17T08:00:00', 114, 'ENTRADA_INICIAL', 8, 0, 8, 'INICIO', 'Carga inicial de inventario', 1),
(115, '2026-08-17T08:00:00', 115, 'ENTRADA_INICIAL', 8, 0, 8, 'INICIO', 'Carga inicial de inventario', 1),
(116, '2026-08-17T08:00:00', 116, 'ENTRADA_INICIAL', 2, 0, 2, 'INICIO', 'Carga inicial de inventario', 1),
(117, '2026-08-17T08:00:00', 117, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(118, '2026-08-17T08:00:00', 118, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(119, '2026-08-17T08:00:00', 119, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(120, '2026-08-17T08:00:00', 120, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(121, '2026-08-17T08:00:00', 121, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(122, '2026-08-17T08:00:00', 122, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(123, '2026-08-17T08:00:00', 123, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(124, '2026-08-17T08:00:00', 124, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(125, '2026-08-17T08:00:00', 125, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(126, '2026-08-17T08:00:00', 126, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(127, '2026-08-17T08:00:00', 127, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(128, '2026-08-17T08:00:00', 128, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(129, '2026-08-17T08:00:00', 129, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(130, '2026-08-17T08:00:00', 130, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(131, '2026-08-17T08:00:00', 131, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(132, '2026-08-17T08:00:00', 132, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(133, '2026-08-17T08:00:00', 133, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(134, '2026-08-17T08:00:00', 134, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(135, '2026-08-17T08:00:00', 135, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(136, '2026-08-17T08:00:00', 136, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(137, '2026-08-17T08:00:00', 137, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(138, '2026-08-17T08:00:00', 138, 'ENTRADA_INICIAL', 15, 0, 15, 'INICIO', 'Carga inicial de inventario', 1),
(139, '2026-08-17T08:00:00', 139, 'ENTRADA_INICIAL', 15, 0, 15, 'INICIO', 'Carga inicial de inventario', 1),
(140, '2026-08-17T08:00:00', 140, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(141, '2026-08-17T08:00:00', 141, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(142, '2026-08-17T08:00:00', 142, 'ENTRADA_INICIAL', 200, 0, 200, 'INICIO', 'Carga inicial de inventario', 1),
(143, '2026-08-17T08:00:00', 143, 'ENTRADA_INICIAL', 200, 0, 200, 'INICIO', 'Carga inicial de inventario', 1),
(144, '2026-08-17T08:00:00', 144, 'ENTRADA_INICIAL', 200, 0, 200, 'INICIO', 'Carga inicial de inventario', 1),
(145, '2026-08-17T08:00:00', 145, 'ENTRADA_INICIAL', 200, 0, 200, 'INICIO', 'Carga inicial de inventario', 1),
(146, '2026-08-17T08:00:00', 146, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(147, '2026-08-17T08:00:00', 147, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(148, '2026-08-17T08:00:00', 148, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(149, '2026-08-17T08:00:00', 149, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(150, '2026-08-17T08:00:00', 150, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(151, '2026-08-17T08:00:00', 151, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(152, '2026-08-17T08:00:00', 152, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(153, '2026-08-17T08:00:00', 153, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(154, '2026-08-17T08:00:00', 154, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(155, '2026-08-17T08:00:00', 155, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(156, '2026-08-17T08:00:00', 156, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(157, '2026-08-17T08:00:00', 157, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(158, '2026-08-17T08:00:00', 158, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(159, '2026-08-17T08:00:00', 159, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(160, '2026-08-17T08:00:00', 160, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(161, '2026-08-17T08:00:00', 161, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(162, '2026-08-17T08:00:00', 162, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(163, '2026-08-17T08:00:00', 163, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(164, '2026-08-17T08:00:00', 164, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(165, '2026-08-17T08:00:00', 165, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(166, '2026-08-17T08:00:00', 166, 'ENTRADA_INICIAL', 2, 0, 2, 'INICIO', 'Carga inicial de inventario', 1),
(167, '2026-08-17T08:00:00', 167, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(168, '2026-08-17T08:00:00', 168, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(169, '2026-08-17T08:00:00', 169, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(170, '2026-08-17T08:00:00', 170, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(171, '2026-08-17T08:00:00', 171, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(172, '2026-08-17T08:00:00', 172, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(173, '2026-08-17T08:00:00', 173, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(174, '2026-08-17T08:00:00', 174, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(175, '2026-08-17T08:00:00', 175, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(176, '2026-08-17T08:00:00', 176, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(177, '2026-08-17T08:00:00', 177, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(178, '2026-08-17T08:00:00', 178, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(179, '2026-08-17T08:00:00', 179, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(180, '2026-08-17T08:00:00', 180, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(181, '2026-08-17T08:00:00', 181, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(182, '2026-08-17T08:00:00', 182, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(183, '2026-08-17T08:00:00', 183, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(184, '2026-08-17T08:00:00', 184, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(185, '2026-08-17T08:00:00', 185, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(186, '2026-08-17T08:00:00', 186, 'ENTRADA_INICIAL', 15, 0, 15, 'INICIO', 'Carga inicial de inventario', 1),
(187, '2026-08-17T08:00:00', 187, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(188, '2026-08-17T08:00:00', 188, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(189, '2026-08-17T08:00:00', 189, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(190, '2026-08-17T08:00:00', 190, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(191, '2026-08-17T08:00:00', 191, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(192, '2026-08-17T08:00:00', 192, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(193, '2026-08-17T08:00:00', 193, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(194, '2026-08-17T08:00:00', 194, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(195, '2026-08-17T08:00:00', 195, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(196, '2026-08-17T08:00:00', 196, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(197, '2026-08-17T08:00:00', 197, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(198, '2026-08-17T08:00:00', 198, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(199, '2026-08-17T08:00:00', 199, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(200, '2026-08-17T08:00:00', 200, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(201, '2026-08-17T08:00:00', 201, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(202, '2026-08-17T08:00:00', 202, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(203, '2026-08-17T08:00:00', 203, 'ENTRADA_INICIAL', 50, 0, 50, 'INICIO', 'Carga inicial de inventario', 1),
(204, '2026-08-17T08:00:00', 204, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(205, '2026-08-17T08:00:00', 205, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(206, '2026-08-17T08:00:00', 206, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(207, '2026-08-17T08:00:00', 207, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(208, '2026-08-17T08:00:00', 208, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(209, '2026-08-17T08:00:00', 209, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(210, '2026-08-17T08:00:00', 210, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(211, '2026-08-17T08:00:00', 211, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(212, '2026-08-17T08:00:00', 212, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(213, '2026-08-17T08:00:00', 213, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(214, '2026-08-17T08:00:00', 214, 'ENTRADA_INICIAL', 5, 0, 5, 'INICIO', 'Carga inicial de inventario', 1),
(215, '2026-08-17T08:00:00', 215, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(216, '2026-08-17T08:00:00', 216, 'ENTRADA_INICIAL', 3, 0, 3, 'INICIO', 'Carga inicial de inventario', 1),
(217, '2026-08-17T08:00:00', 217, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(218, '2026-08-17T08:00:00', 218, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(219, '2026-08-17T08:00:00', 219, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(220, '2026-08-17T08:00:00', 220, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(221, '2026-08-17T08:00:00', 221, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(222, '2026-08-17T08:00:00', 222, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(223, '2026-08-17T08:00:00', 223, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(224, '2026-08-17T08:00:00', 224, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(225, '2026-08-17T08:00:00', 225, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(226, '2026-08-17T08:00:00', 226, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(227, '2026-08-17T08:00:00', 227, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(228, '2026-08-17T08:00:00', 228, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(229, '2026-08-17T08:00:00', 229, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(230, '2026-08-17T08:00:00', 230, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(231, '2026-08-17T08:00:00', 231, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(232, '2026-08-17T08:00:00', 232, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1),
(233, '2026-08-17T08:00:00', 233, 'ENTRADA_INICIAL', 10, 0, 10, 'INICIO', 'Carga inicial de inventario', 1),
(234, '2026-08-17T08:00:00', 234, 'ENTRADA_INICIAL', 30, 0, 30, 'INICIO', 'Carga inicial de inventario', 1),
(235, '2026-08-17T08:00:00', 235, 'ENTRADA_INICIAL', 20, 0, 20, 'INICIO', 'Carga inicial de inventario', 1);
SET IDENTITY_INSERT movimientos_inventario OFF;
GO

-- ==============================================================================
-- 7. RECURSOS HUMANOS Y NÓMINA
-- ==============================================================================

CREATE TABLE empleados (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    identificacion VARCHAR(30) UNIQUE,
    cargo VARCHAR(100),
    salario_base DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    fecha_ingreso DATE,
    activo BIT DEFAULT 1,
    created_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE nomina (
    id INT IDENTITY(1,1) PRIMARY KEY,
    periodo_mes INT NOT NULL,
    periodo_anio INT NOT NULL,
    fecha_generacion DATETIME DEFAULT GETDATE(),
    total_ingresos DECIMAL(12, 2) DEFAULT 0.00,
    total_deducciones DECIMAL(12, 2) DEFAULT 0.00,
    total_neto DECIMAL(12, 2) DEFAULT 0.00
);
GO

CREATE TABLE detalle_nomina (
    id INT IDENTITY(1,1) PRIMARY KEY,
    nomina_id INT NOT NULL,
    empleado_id INT NOT NULL,
    salario_base DECIMAL(12, 2) NOT NULL,
    inss_laboral DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    ir DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    otras_deducciones DECIMAL(12, 2) DEFAULT 0.00,
    neto_pagar DECIMAL(12, 2) NOT NULL,
    CONSTRAINT fk_detnomina_nomina FOREIGN KEY (nomina_id) REFERENCES nomina(id) ON DELETE CASCADE,
    CONSTRAINT fk_detnomina_empleado FOREIGN KEY (empleado_id) REFERENCES empleados(id)
);
GO

-- ==============================================================================
-- 8. CONTABILIDAD Y ESTADOS FINANCIEROS
-- ==============================================================================

CREATE TABLE cuentas_contables (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo_cuenta VARCHAR(20) NOT NULL UNIQUE,
    nombre_cuenta VARCHAR(150) NOT NULL,
    tipo_cuenta VARCHAR(50) NOT NULL CHECK (tipo_cuenta IN ('Activo', 'Pasivo', 'Capital', 'Ingreso', 'Costo', 'Gasto')),
    saldo_actual DECIMAL(12, 2) DEFAULT 0.00,
    created_at DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE asientos_contables (
    id INT IDENTITY(1,1) PRIMARY KEY,
    fecha DATETIME DEFAULT GETDATE(),
    descripcion VARCHAR(255) NOT NULL,
    referencia VARCHAR(100),
    total_debe DECIMAL(12, 2) DEFAULT 0.00,
    total_haber DECIMAL(12, 2) DEFAULT 0.00
);
GO

CREATE TABLE detalle_asientos (
    id INT IDENTITY(1,1) PRIMARY KEY,
    asiento_id INT NOT NULL,
    cuenta_id INT NOT NULL,
    debe DECIMAL(12, 2) DEFAULT 0.00,
    haber DECIMAL(12, 2) DEFAULT 0.00,
    CONSTRAINT fk_detasiento_asiento FOREIGN KEY (asiento_id) REFERENCES asientos_contables(id) ON DELETE CASCADE,
    CONSTRAINT fk_detasiento_cuenta FOREIGN KEY (cuenta_id) REFERENCES cuentas_contables(id)
);
GO
